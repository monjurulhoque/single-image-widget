# Single Image Widget

Contributors: monjurulhoque, saucerweb
Tags: Single Image Widget, Image Widget, widget, media Image Widget, media manager Image Widget, sidebar Image Widget, image Widget, photo Widget, picture Widget 
Requires at least: 4.0  
Tested up to: 4.7  
Stable tag: 4.6  
License: GPL-2.0+  
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Single Image Widget to add any images to your sidebars.

## Description

single image Widget is what the name implies -- the easiest way to add images to your sidebars. Display advertisements, calls-to-action, or even build a slider based on image widgets.

Despite its simplicity, single image Widget is built with extensibility in mind, making it super easy to spin off new image-based widgets, or customize the widget ouput using the available template hierarchy.

### Additional Resources

* [Write a review](https://wordpress.org/plugins/single-image-widget/)
* [Contribute on GitHub](https://github.com/monjurulhoque/single-image-widget)
* [Follow @monjurulhoque](https://twitter.com/monjurulhoque)
* [Like @saucerweb](https://facebook.com/saucerwebsolutions)

## Installation

Install just like most other plugins. Download or Install it first then active it. its so simple to manage.


## Frequently Asked Questions


## Screenshots

1. single image Widget


## Changelog
